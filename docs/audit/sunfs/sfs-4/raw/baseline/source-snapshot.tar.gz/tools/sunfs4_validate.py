#!/usr/bin/env python3
"""SFS-4 hosted qualification. Never modifies previous milestone evidence."""
import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import tarfile
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs/audit/sunfs/sfs-4'
CRATES = ['sunlight-sunfs', 'sunlight-sunfs-lab', 'sunlight-sunfs-check']

def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''):
            h.update(b)
    return h.hexdigest()

def write(p, v):
    p.write_text(json.dumps(v, indent=2)+'\n')

def sources():
    paths = [ROOT/'Cargo.toml', ROOT/'Cargo.lock', pathlib.Path(__file__)]
    for crate in CRATES:
        paths += [p for p in (ROOT/crate).rglob('*') if p.is_file()]
    return {str(p.relative_to(ROOT)): sha(p) for p in sorted(paths)}

def cargo(action, packages=CRATES, extra=()):
    return ['cargo', action, *sum((['-p', p] for p in packages), []), '--offline', '--locked', *extra]

def run(argv, raw, name, env=None):
    start = time.monotonic_ns()
    with (raw/name).open('w') as f:
        p = subprocess.run(argv, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, env=env)
    row = dict(argv=argv, returncode=p.returncode, elapsed_ns=time.monotonic_ns()-start, log=name)
    with (raw/'commands.jsonl').open('a') as f:
        f.write(json.dumps(row)+'\n')
    print(name, p.returncode, flush=True)
    if p.returncode:
        raise RuntimeError(row)

def baseline():
    assert not (OUT/'source-baseline.json').exists()
    names = subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'], cwd=ROOT).decode().split('\0')
    hashes = {n:sha(ROOT/n) for n in names if n and not n.startswith('docs/audit/sunfs/sfs-4/') and (ROOT/n).is_file() and not (ROOT/n).is_symlink()}
    raw = OUT/'raw/baseline'
    write(OUT/'source-baseline.json', dict(revision=subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT).decode().strip(), branch=subprocess.check_output(['git','branch','--show-current'], cwd=ROOT).decode().strip(), status=subprocess.check_output(['git','status','--porcelain=v1'], cwd=ROOT).decode(), sha256=hashes))
    before=sources()
    write(raw/'compiled-source.json',before)
    with tarfile.open(raw/'source-snapshot.tar.gz','w:gz') as a:
        for name in before:
            a.add(ROOT/name,arcname=name,recursive=False)
    run(cargo('check',['sunlight-sunfs'],['--target','x86_64-unknown-none']),raw,'no-std.log')
    for profile in ['dev','release']:
        host=['--target','x86_64-unknown-linux-gnu']+(['--release'] if profile=='release' else [])
        env=dict(os.environ)
        for sub, key in [('sfs1','SUNFS_EVIDENCE_DIR'),('sfs2','SUNFS_SFS2_EVIDENCE_DIR'),('sfs3','SUNFS_SFS3_EVIDENCE_DIR')]:
            p=raw/profile/sub
            p.mkdir(parents=True)
            env[key]=str(p)
        run(cargo('test',extra=[*host,'--','--nocapture']),raw,f'{profile}.log',env)
        run(cargo('build',['sunlight-sunfs-lab','sunlight-sunfs-check'],[*host,'--bins','--examples']),raw,f'build-{profile}.log')
    assert before==sources()
    write(raw/'result.json',dict(status='PASS',source_sha256=before))

if __name__ == '__main__':
    if sys.argv[1:]==['--baseline']:
        baseline()
